import javax.swing.*;
import java.awt.event.*;




public class WelcomePage extends JFrame implements ActionListener {

	 	private JTextArea jTextArea1;
	    private JButton jButton1;
	    private JTextPane jTextPane1;
	    private JButton jButton2;
	    private JButton jButton3;
	    private JButton jButton4;
    	private JLabel jLabel1;




    public WelcomePage() {
        initComponents ();

    }


    private void initComponents() {

        JPanel panel=new JPanel();


        jTextArea1 = new JTextArea();
        jButton1 = new JButton();

        jButton2 = new JButton();
        jButton3 = new JButton();
        jButton4 = new JButton();
        jLabel1 = new JLabel();
        panel.setLayout(null);
        setName("WelcomePage");
        setTitle("Welcome Page");
        panel.setForeground(java.awt.Color.lightGray);


        panel.setBackground(new java.awt.Color (0, 0, 64));


        jTextArea1.setLineWrap(true);
        jTextArea1.setBorder(new javax.swing.border.SoftBevelBorder(0));
        jTextArea1.setEditable(false);
        jTextArea1.setColumns(1);
        jTextArea1.setRows(2);
        jTextArea1.setForeground(java.awt.Color.lightGray);
        jTextArea1.setFont(new java.awt.Font ("Times New Roman", 1, 14));
        jTextArea1.setText("University banking is an easy way for fulfilling & dealing the needs of the students banking  which includes tuition fees, scholarships etc.   You will find complete information regarding    this banking throughout this program\u2026.");
        jTextArea1.setBackground(new java.awt.Color (0, 0, 64));
		jTextArea1.setBounds(190, 100, 294, 140);
        panel.add(jTextArea1);



        jButton1.setText("About");
		jButton1.setBounds(40, 100, 90, 30);

        panel.add(jButton1);
        jButton1.addActionListener(this);






        jButton2.setText("How to use");


        jButton2.setLocation(40, 150);
        jButton2.setSize(jButton2.getPreferredSize());
		panel.add(jButton2);
		jButton2.addActionListener(this);

        jButton3.setText("Exit");


        jButton3.setBounds(40, 200, 90, 30);
		panel.add(jButton3);
		jButton3.addActionListener(this);


        jButton4.setText("Continue");

        jButton4.setLocation(400, 280);
        jButton4.setSize(jButton4.getPreferredSize());
		panel.add(jButton4);
		jButton4.addActionListener(this);

        jLabel1.setBorder(new javax.swing.border.LineBorder(java.awt.Color.black, 4));
        jLabel1.setName("lblTitle");
        jLabel1.setText("University Banking System");
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setBackground(new java.awt.Color (0, 0, 64));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setFont(new java.awt.Font ("Helvetica", 1, 18));
		jLabel1.setBounds(80, 30, 340, 40);

        panel.add(jLabel1);

        getContentPane().add(panel);
        setVisible(true);
        setSize(575,475);


    }

    public static void main (String args[]) {
        new WelcomePage ();
    }


	public void actionPerformed(ActionEvent e)
	{

		JButton button= (JButton)e.getSource();

		if(button.equals(jButton1))
		{

			new About();
			this.dispose();

		}

		else if(button.equals(jButton2))
		{

				new How();
				this.dispose();

		}

		else if(button.equals(jButton3))
		{
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			System.exit(0);

		}

		else
		{
			new HomePage();
			this.dispose();

		}




	}



}
