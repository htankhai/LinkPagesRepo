import javax.swing.*;
import java.awt.event.*;




public class About extends JFrame implements ActionListener {

	 	private JTextArea jTextArea1;
	    private JButton ok;
	    private JTextPane jTextPane1;
	    private JLabel jLabel1;




    public About()
    {
        initComponents ();

    }


    private void initComponents() {

        JPanel panel=new JPanel();


        jTextArea1 = new JTextArea();
        ok = new JButton();
        jLabel1=new JLabel();

        panel.setLayout(null);
        setName("About");
        setTitle("About");
        panel.setForeground(java.awt.Color.lightGray);


        panel.setBackground(new java.awt.Color (0, 0, 64));


        jTextArea1.setLineWrap(true);
        jTextArea1.setBorder(new javax.swing.border.SoftBevelBorder(0));
        jTextArea1.setEditable(false);
        jTextArea1.setColumns(1);
        jTextArea1.setRows(2);
        jTextArea1.setForeground(java.awt.Color.lightGray);
        jTextArea1.setFont(new java.awt.Font ("Times New Roman", 1, 14));
        jTextArea1.setText("       UNIVERSITY BANKING SYSTEM.\n\tVersion 1.1.\n                      Submitted by\n                      Irina Hashmi\n\t       & \n               Syeda Sakira Hassan\n                     Supervised by\n             Chowdhury Farhan Ahmed");


        jTextArea1.setBackground(new java.awt.Color (0, 0, 64));
		jTextArea1.setBounds(190, 100, 294, 140);//may be axis
        panel.add(jTextArea1);




        ok.setText("Ok");

		        ok.setLocation(400, 280);
		        ok.setSize(ok.getPreferredSize());
				panel.add(ok);
				ok.addActionListener(this);





        jLabel1.setBorder(new javax.swing.border.LineBorder(java.awt.Color.black, 4));
        jLabel1.setName("lblTitle");
        jLabel1.setText("University Banking System");
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setBackground(new java.awt.Color (0, 0, 64));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setFont(new java.awt.Font ("Helvetica", 1, 18));
		jLabel1.setBounds(80, 30, 340, 40);

        panel.add(jLabel1);

        getContentPane().add(panel);
        setVisible(true);
        setSize(575,475);


    }




	public void actionPerformed(ActionEvent e)
	{

		JButton button= (JButton)e.getSource();

		if(button.equals(ok))
		{

			new WelcomePage();
			this.dispose();

		}




	}



}
