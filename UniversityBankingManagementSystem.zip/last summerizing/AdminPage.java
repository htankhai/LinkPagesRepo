import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class AdminPage extends JFrame implements ActionListener
{


		JLabel lblUpdate;
		JLabel lblSearch;

		JButton btnSesFees;
        JButton btnScholarFees;
		JButton btnFine;

		JButton btnSingleView;
		JButton btnViewAll;

		JButton btnCancel;


		Color ASH =new Color(224,224,224);

	AdminPage()
	{

		setTitle("Administrator's Page");
		JPanel panel=new JPanel();

		panel.setLayout(null);
		panel.setBackground(new Color(0,0,64));



		lblUpdate=new JLabel("Update");
		lblSearch=new JLabel("Search");

		lblUpdate.setForeground(ASH);
		lblUpdate.setBorder(new javax.swing.border.SoftBevelBorder(0));
		lblUpdate.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdate.setBounds(40, 40, 140, 30);

		lblSearch.setForeground(ASH);
		lblSearch.setBorder(new javax.swing.border.SoftBevelBorder(0));
		lblSearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearch.setBounds(240,40,250, 30);



		panel.add(lblUpdate);
		panel.add(lblSearch);


		btnSesFees=new JButton("Session Fees");
		btnScholarFees=new JButton("Scholarship");
		btnFine=new JButton("Fine");

		btnSesFees.setLocation(55,100);
		btnSesFees.setSize(btnSesFees.getPreferredSize());

		btnScholarFees.setLocation(55,150);
		btnScholarFees.setSize(btnScholarFees.getPreferredSize());

        btnFine.setLocation(70,200);
		btnFine.setSize(btnFine.getPreferredSize());

		panel.add(btnSesFees);
		btnSesFees.addActionListener(this);
		panel.add(btnScholarFees);
		btnScholarFees.addActionListener(this);
		panel.add(btnFine);
		btnFine.addActionListener(this);

		btnSingleView=new JButton("Single View");
		btnViewAll=new JButton("View All");

        btnSingleView.setLocation(330,130);
		btnSingleView.setSize(btnSingleView.getPreferredSize());

		btnViewAll.setLocation(340,180);
		btnViewAll.setSize(btnViewAll.getPreferredSize());

		panel.add(btnSingleView);
		btnSingleView.addActionListener(this);

		panel.add(btnViewAll);
		btnViewAll.addActionListener(this);

		btnCancel=new JButton("Cancel");
		btnCancel.setBounds(120,250,250,30);
		panel.add(btnCancel);
		btnCancel.addActionListener(this);

		getContentPane().add(panel);
		setVisible(true);
		setSize(530,350);
	}






	public void actionPerformed(ActionEvent e)

	{

		JButton button=(JButton)e.getSource();

		if(button.equals(btnSesFees))
		{


			new Session();
			this.dispose();

		}

		else if(button.equals(btnScholarFees))

		{

			new Scholar();
			this.dispose();

		}

		else if(button.equals(btnFine))
		{

			new Fine();
			this.dispose();
		}

		else if(button.equals(btnSingleView))
		{

				new ViewAccount();
				this.dispose();
		}
		else if(button.equals(btnViewAll))
		{

				new	ViewAll();
				this.dispose();
		}

		else
		{

			new HomePage();
			this.dispose();
		}

	}

}