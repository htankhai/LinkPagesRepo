import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;


public class ViewAll extends JFrame implements ActionListener{

	private JPanel panel = new JPanel ();

	private DefaultTableModel dtmStudent;
	private JTable tbStudent;
	private JScrollPane scroll;

	private int row = 0;
	private int total = 0;


	private String rowData[][];

	private FileInputStream fis;
	private DataInputStream dis;
	private JButton jButton1;

	ViewAll () {


		setSize (800, 700);
		setTitle("View All Account Status");

		panel.setLayout (null);
		panel.setBackground(new Color(0,0,64));
		populateArray ();

		tbStudent = makeTable ();

		JLabel label=new JLabel("University Banking System");

		label.setBorder(new javax.swing.border.LineBorder(java.awt.Color.black, 4));
		label.setName("lblTitle");
		label.setForeground(java.awt.Color.white);
		label.setBackground(new java.awt.Color (0, 0, 64));
		label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		label.setFont(new java.awt.Font ("Helvetica", 1, 18));
		label.setBounds(100, 10, 500, 30);

        panel.add(label);



		int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
		int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
		scroll = new JScrollPane (tbStudent,v,h);
		scroll.setBounds (20, 45, 700, 400);


		panel.add (scroll);

		jButton1=new JButton("OK");
		jButton1.setBounds(300, 500, 90, 30);

		 panel.add(jButton1);
		 jButton1.addActionListener(this);


		getContentPane().add (panel);


		setVisible (true);

	}


	public void actionPerformed(ActionEvent e)
	{

		JButton btn=(JButton)e.getSource();
		if(btn.equals(jButton1))
		{
			new AdminPage();
			this.dispose();
		}
	}
	void populateArray () {


		String rows[][] = new String [500][20];
		try {
			fis = new FileInputStream ("Student.dat");
			dis = new DataInputStream (fis);

			while (true) {
				for (int i = 0; i <20 ; i++) {
					rows[row][i] = dis.readUTF ();
				}
				row++;
			}
		}
		catch (Exception ex) {
			total = row;
			rowData = new String [total][10];
			if (total == 0) {
				JOptionPane.showMessageDialog (null, "Records File is Empty.\nEnter Records to Display.",
							"BankSystem - EmptyFile", JOptionPane.PLAIN_MESSAGE);
			}
			else {
				for (int i = 0; i < total; i++) {
					rowData[i][0] = rows[i][10];
					rowData[i][1] = rows[i][1]+" "+rows[i][2]+" "+rows[i][3];
					rowData[i][2] = rows[i][9];
					rowData[i][3] = rows[i][16];
					rowData[i][4] = rows[i][17];
					rowData[i][5] = rows[i][13];
					rowData[i][6] = rows[i][14];
					rowData[i][7] = rows[i][15];
					rowData[i][8] = rows[i][18];
					rowData[i][9] = rows[i][19];
				}
				try {
					dis.close();
					fis.close();
				}
				catch (Exception exp) { }
			}
		}

	}


	private JTable makeTable () {


		String cols[] = {"Account No.", "Student Name", "Email ID","Session","Year","Session Fees","Exam Fees","Scholarship","Fine","Last Update"};

		dtmStudent  = new DefaultTableModel (rowData, cols);
		tbStudent = new JTable (dtmStudent) {
			public boolean isCellEditable (int iRow, int iCol) {
				return false;
			}
		};

		(tbStudent.getColumnModel().getColumn(0)).setPreferredWidth (200);
		(tbStudent.getColumnModel().getColumn(1)).setPreferredWidth (450);
		(tbStudent.getColumnModel().getColumn(2)).setPreferredWidth (400);
		(tbStudent.getColumnModel().getColumn(3)).setPreferredWidth (250);
		(tbStudent.getColumnModel().getColumn(4)).setPreferredWidth (250);
		(tbStudent.getColumnModel().getColumn(5)).setPreferredWidth (250);
		(tbStudent.getColumnModel().getColumn(6)).setPreferredWidth (250);
		(tbStudent.getColumnModel().getColumn(7)).setPreferredWidth (250);
		(tbStudent.getColumnModel().getColumn(8)).setPreferredWidth (200);
		(tbStudent.getColumnModel().getColumn(9)).setPreferredWidth (200);
		tbStudent.setRowHeight (20);
		tbStudent.setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
		return tbStudent;

	}




}