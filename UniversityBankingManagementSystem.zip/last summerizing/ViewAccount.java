import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;




public class ViewAccount extends JFrame implements ActionListener
{

	JLabel lblAccountID;

	JTextField txtAccountID;

	JButton btnView;

	JButton btnCancel;
	Color DARKBLUE=new Color(0,0,64);
	Color FONTCOLOR=new Color(224,224,224);

		FileInputStream fis;
		FileOutputStream fos;
		DataOutputStream dos;
		DataInputStream dis;

		private int count = 0;
		private int rows = 0;
		private	int total = 0;


		private String records[][] = new String [500][20];



	public ViewAccount()
	{

		this.setTitle("View Account Status");
		JPanel panel=new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbCons=new GridBagConstraints();
		gbCons.gridx=0;
		gbCons.gridy=0;
		lblAccountID= new JLabel("Account ID ");
		lblAccountID.setForeground(FONTCOLOR);
		panel.add(lblAccountID,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=0;
		txtAccountID= new JTextField(20);
		panel.add(txtAccountID,gbCons);




		JPanel btnPanel=new JPanel();
		btnPanel.setBackground(DARKBLUE);
		btnView=new JButton("View");
		btnPanel.add(btnView);
		btnView.addActionListener(this);

		btnCancel=new JButton("Cancel");
		btnPanel.add(btnCancel);
		btnCancel.addActionListener(this);

		gbCons.gridx=1;
		gbCons.gridy=3;
		gbCons.anchor=GridBagConstraints.CENTER;
		panel.add(btnPanel,gbCons);

		panel.setBackground(DARKBLUE);

		getContentPane().add(panel);
		setVisible(true);
		setSize(450,200);


		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}


public static void main(String args[])
{
	new ViewAccount();
}


	public void actionPerformed(ActionEvent e)
	{

			JButton button=(JButton)e.getSource();

			if(button.equals(btnCancel))
			{

				new AdminPage();
				this.dispose();
			}
			else
			{
				int var=verify();
					if(var==1)
						{

							rows = 0;
							populateArray ();
							findRec ();
							this.dispose();


						}
						else
						{

							JOptionPane.showMessageDialog(null,"You might forget to fill the ID !!!","Warning",JOptionPane.ERROR_MESSAGE);

									new ViewAccount();
									this.dispose();
							}

			}


	}




		private	void populateArray () {

						try {
							fis = new FileInputStream ("Student.dat");
							dis = new DataInputStream (fis);

							while (true) {
								for (int i = 0; i < 20; i++) {
									records[rows][i] = dis.readUTF ();
								}
								rows++;
							}
						}
						catch (Exception ex) {
							total = rows;
							if (total == 0) {
								JOptionPane.showMessageDialog (null, "Records File is Empty.\nEnter Records First to Display.",
											"BankSystem - EmptyFile", JOptionPane.PLAIN_MESSAGE);

							}
							else {
								try {
									dis.close();
									fis.close();
								}
								catch (Exception exp) { }
							}
						}

					}

					void findRec () {

						boolean found = false;
						for (int x = 0; x < total; x++) {


							if (records[x][10].equals(txtAccountID.getText())){
											found = true;
											new View (x);
											break;

								}

						}

						if (found == false) {
							JOptionPane.showMessageDialog (this, "Account No. " + txtAccountID.getText () + " doesn't Exist.",
											"UniversityBankSystem - WrongNo", JOptionPane.PLAIN_MESSAGE);


							new ViewAccount();

						}

			}



			private int verify()
			{

				int ctrl=0;
				String ID=txtAccountID.getText();


				if( (ID.length()>0) )
					{
						ctrl=1;
						return ctrl;
					}

				return ctrl;
			}


}