import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Calendar;


public class Fine extends JFrame implements ActionListener{


     private javax.swing.JLabel lblAccountID;
	    private javax.swing.JTextField txtAccountID;
	    private javax.swing.JComboBox cboFine;
	    private javax.swing.JButton btnUpdate;
		FileInputStream fis;
		DataInputStream dis;
		String records[][]=new String [500][20];
		String[] str={"Fine","NIL"};
		int total=0;
		int rows=0;




   public Fine() {

        this.setTitle("Updating Status");
        JPanel panel=new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(0,0,64));


        lblAccountID = new javax.swing.JLabel("Account ID");
        lblAccountID.setForeground(new Color(224,224,224));
        txtAccountID = new javax.swing.JTextField(20);

        cboFine = new javax.swing.JComboBox(str);
        btnUpdate = new javax.swing.JButton("Update");

        GridBagConstraints gbCons= new java.awt.GridBagConstraints();


        gbCons.gridx=0;
        gbCons.gridy=0;
        panel.add(lblAccountID, gbCons);


       gbCons.gridx=0;
	   gbCons.gridy=1;
	   panel.add(txtAccountID,gbCons);

		gbCons.gridx=0;
	   gbCons.gridy=2;

	   cboFine.setSelectedIndex(0);
	   panel.add(cboFine,gbCons);



		gbCons.gridx=0;
	   gbCons.gridy=3;
	   panel.add(btnUpdate,gbCons);
		btnUpdate.addActionListener(this);

		getContentPane().add(panel);
       setVisible(true);
       setSize(300,200);

    }
    public static void main (String args[]) {
        new Fine();
    }







	public void actionPerformed (ActionEvent e)
	{

			JButton obj = (JButton)e.getSource();

			if (obj.equals(btnUpdate) ) {
				if (txtAccountID.getText().equals("")) {
					JOptionPane.showMessageDialog (this, "Please! Provide Id of Student.",
							"BankSystem - EmptyField", JOptionPane.PLAIN_MESSAGE);

				}
				else {
					rows = 0;
					populateArray ();
					findRec ();
					new AdminPage();
					this.dispose();

				}
			}

		}



	void populateArray () {

		try {
			fis = new FileInputStream ("Student.dat");
			dis = new DataInputStream (fis);

			while (true) {
				for (int i = 0; i < 20; i++) {
					records[rows][i] = dis.readUTF ();
				}
				rows++;
			}
		}
		catch (Exception ex) {
			total = rows;
			if (total == 0) {
				JOptionPane.showMessageDialog (null, "Records File is Empty.\nEnter Records First to Display.",
							"BankSystem - EmptyFile", JOptionPane.PLAIN_MESSAGE);

			}
			else {
				try {
					dis.close();
					fis.close();
				}
				catch (Exception exp) { }
			}
		}

	}


	void findRec () {

		boolean found = false;
		for (int x = 0; x < total; x++) {
			if (records[x][10].equals (txtAccountID.getText())) {
				found = true;
				editRec (x);
				break;
			}
		}
		if (found == false) {
			String str = txtAccountID.getText ();

			JOptionPane.showMessageDialog (this, "Account No. " + str + " doesn't Exist.",
						"BankSystem - WrongNo", JOptionPane.PLAIN_MESSAGE);

					}

	}





	public void editRec (int recCount) {

		Calendar cal=Calendar.getInstance();
		String a=cal.get(Calendar.DATE)+"/"+(cal.get(Calendar.MONTH)+1)+"/"+cal.get(Calendar.YEAR);
		records[recCount][18] = "" + cboFine.getSelectedItem ();
		records[recCount][19] =a;
		editFile ();	//Save This Array to File.

	}

	//Function use to Save Records to File After editing the Record of User Choice.
	public void editFile () {

		try {
			FileOutputStream fos = new FileOutputStream ("Student.dat");
			DataOutputStream dos = new DataOutputStream (fos);
			if (records != null) {
				for (int i = 0; i < total; i++) {
					for (int c = 0; c < 20; c++) {
						dos.writeUTF (records[i][c]);
						if (records[i][c] == null) break;
					}
				}
				JOptionPane.showMessageDialog (this, "The File is Updated Successfully",
						"BankSystem - Record Saved", JOptionPane.PLAIN_MESSAGE);

				dos.close();
				fos.close();
			}
		}
		catch (IOException ioe) {
			JOptionPane.showMessageDialog (this, "There are Some Problem with File",
						"BankSystem - Problem", JOptionPane.PLAIN_MESSAGE);
		}

	}





}
