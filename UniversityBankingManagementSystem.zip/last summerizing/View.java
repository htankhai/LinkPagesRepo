import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;




public class View extends JFrame implements ActionListener
{


	JLabel lblAccountID;
	JLabel txtAccountID;
	JLabel lblName;
	JLabel txtName;
	JLabel lblEmailID;
	JLabel txtEmailID;
	JButton btnOk;

	private DefaultTableModel dtmStudent;
	private JTable tbStudent;
	private JScrollPane scroll;
	private int row = 0;
	private int total = 0;


	private String rowData[][];
	private String records[][];

	private FileInputStream fis;
	private DataInputStream dis;

	Color DARKBLUE=new Color(0,0,64);
	Color FONTCOLOR=new Color(224,224,224);




	public View(int Rec)
	{


		this.setTitle("View Account Status");
		JPanel panel = new JPanel ();
		panel.setLayout(null);


		populateArray (Rec);
		tbStudent = makeTable ();


		lblAccountID= new JLabel("Account ID ");
		lblAccountID.setForeground(FONTCOLOR);
		lblAccountID.setBounds(10,10,100,10);
		panel.add(lblAccountID);


		txtAccountID= new JLabel("");
		txtAccountID.setForeground(FONTCOLOR);
		txtAccountID.setBounds(130,10,100,10);
		txtAccountID.setText(records[0][0]);
		panel.add(txtAccountID);



		lblName= new JLabel("Name ");
		lblName.setForeground(FONTCOLOR);
		lblName.setBounds(10,30,100,10);
		panel.add(lblName);


		txtName= new JLabel("");
		txtName.setForeground(FONTCOLOR);
		txtName.setText(records[0][1]);
		txtName.setBounds(130,30,200,10);
		panel.add(txtName);



		lblEmailID= new JLabel("Email ID ");
		lblEmailID.setForeground(FONTCOLOR);
		lblEmailID.setBounds(10,50,100,10);
		panel.add(lblEmailID);


		txtEmailID= new JLabel("");
		txtEmailID.setForeground(FONTCOLOR);
		txtEmailID.setText(records[0][2]);
		txtEmailID.setBounds(130,50,200,10);
		panel.add(txtEmailID);



		btnOk=new JButton("Ok");
		btnOk.setBounds(270,250,50,20);
		panel.add(btnOk);
		btnOk.addActionListener(this);





		scroll = new JScrollPane (tbStudent);


		scroll.setBounds (20, 80, 550,150);
		panel.add (scroll);


		getContentPane().add (panel);



		panel.setBackground(DARKBLUE);

		getContentPane().add(panel);
		setVisible(true);
		setSize(600,350);


		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}



	public void actionPerformed(ActionEvent e)
	{

			JButton button=(JButton)e.getSource();

			if(button.equals(btnOk))
			{

				new HomePage();
				this.dispose();
			}

	}


void populateArray (int intRec) {


		String rows[][] = new String [500][20];
		try {
			fis = new FileInputStream ("Student.dat");
			dis = new DataInputStream (fis);

			while (true) {
				for (int i = 0; i <20 ; i++) {
					rows[row][i] = dis.readUTF ();
				}
				row++;
			}
		}
		catch (Exception ex) {
			total = row;
			rowData = new String [1][20];
			records =new String [1][20];
			if (total == 0) {
				JOptionPane.showMessageDialog (null, "Records File is Empty.\nEnter Records to Display.",
							"BankSystem - EmptyFile", JOptionPane.PLAIN_MESSAGE);
			}
			else {
					 {
						rowData[0][0] = rows[intRec][16];
						rowData[0][1] = rows[intRec][17];
						rowData[0][2] = rows[intRec][13];
						rowData[0][3] = rows[intRec][14];
						rowData[0][4] = rows[intRec][15];
						rowData[0][5] = rows[intRec][18];
						rowData[0][6] = rows[intRec][19];

						records[0][0]=rows[intRec][10];
						records[0][1]=rows[intRec][1]+" "+rows[intRec][2]+" "+rows[intRec][3];
						records[0][2]=rows[intRec][9];

				}
				try {
					dis.close();
					fis.close();
				}
				catch (Exception exp) { }
			}
		}

	}
		private JTable makeTable () {


				String cols[] = {"Session", "Year", "Session Fees","Exam Fees","Scholarship","Fine","Last Update"};

				dtmStudent  = new DefaultTableModel (rowData, cols);
				tbStudent = new JTable (dtmStudent) {
					public boolean isCellEditable (int iRow, int iCol) {
						return false;
					}
				};

				(tbStudent.getColumnModel().getColumn(0)).setPreferredWidth (100);
				(tbStudent.getColumnModel().getColumn(1)).setPreferredWidth (200);
				(tbStudent.getColumnModel().getColumn(2)).setPreferredWidth (200);
				(tbStudent.getColumnModel().getColumn(3)).setPreferredWidth (200);
				(tbStudent.getColumnModel().getColumn(4)).setPreferredWidth (200);
				(tbStudent.getColumnModel().getColumn(5)).setPreferredWidth (200);
				(tbStudent.getColumnModel().getColumn(6)).setPreferredWidth (200);
				tbStudent.setRowHeight (24);

				tbStudent.setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
				return tbStudent;

	}
}