import javax.swing.*;

import java.awt.*;
import java.awt.event.*;



public class HomePage extends JFrame implements ActionListener
{


		JLabel lblStuTitle;
		JLabel lblAdminTitle;
		JButton btnRegister;

		JButton btnLogin1;
		JButton btnLogin2;
		JButton btnCancel;

		Color ASH =new Color(224,224,224);

	HomePage()
	{

		setTitle("Home Page");
		JPanel panel=new JPanel();

		panel.setLayout(null);
		panel.setBackground(new Color(0,0,64));



		lblStuTitle=new JLabel("Students' Home Page");
		lblAdminTitle=new JLabel("Administrator's Home Page");
		lblStuTitle.setBorder(new javax.swing.border.SoftBevelBorder(0));
		lblStuTitle.setBounds(40, 90, 140, 30);

		lblStuTitle.setForeground(ASH);


		lblAdminTitle.setForeground(ASH);
		lblAdminTitle.setBorder(new javax.swing.border.SoftBevelBorder(0));
		lblAdminTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminTitle.setBounds(240,90,250, 30);



		panel.add(lblStuTitle);
		panel.add(lblAdminTitle);


		btnRegister=new JButton("Register");
		btnLogin1=new JButton("Login");
		btnRegister.setLocation(55, 140);
		btnRegister.setSize(btnRegister.getPreferredSize());
		btnLogin1.setLocation(62,180);
		btnLogin1.setSize(btnLogin1.getPreferredSize());

		panel.add(btnRegister);
		btnRegister.addActionListener(this);
		panel.add(btnLogin1);
		btnLogin1.addActionListener(this);


		btnLogin2=new JButton("Login");

		btnLogin2.setLocation(330,155);
		btnLogin2.setSize(btnLogin2.getPreferredSize());

		panel.add(btnLogin2);
		btnLogin2.addActionListener(this);



		btnCancel=new JButton("Cancel");
		btnCancel.setBounds(120,250,250,30);
		panel.add(btnCancel);
		btnCancel.addActionListener(this);

		getContentPane().add(panel);
		setVisible(true);
		setSize(530,350);
	}






	public void actionPerformed(ActionEvent e)

	{

		JButton button=(JButton)e.getSource();

		if(button.equals(btnRegister))
		{

			new Register();
			this.dispose();

		}

		else if(button.equals(btnLogin1))

		{

			new Login();
			this.dispose();

		}

		else if(button.equals(btnLogin2))
		{

			new AdminLogin();
			this.dispose();
		}

		else
		{

			new WelcomePage();
			this.dispose();
		}

	}

}