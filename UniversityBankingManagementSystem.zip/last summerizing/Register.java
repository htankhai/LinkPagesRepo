import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.Calendar;


public class Register extends JFrame implements ActionListener
{

	JLabel lblHeading;
	JLabel lblAcctType;
	JLabel lblFirstName;
	JLabel lblMidName;
	JLabel lblLastName;
	JLabel lblSex;
	JLabel lblAge;
	JLabel lblNationality;
	JLabel lblPreAddr;
	JLabel lblPerAddr;
	JLabel lblEmailID;
	JLabel lblAdminID;
	JLabel lblStuPwd;
	JLabel lblCnfStuPwd;
	JLabel lblPhone;



	JComboBox lstAcctType;
	JTextField txtFirstName;
	JTextField txtMidName;
	JTextField txtLastName;
	JComboBox lstSex;
	JTextField txtAge;
	JTextField txtNationality;
	JTextField txtPreAddr;
	JTextField txtPerAddr;
	JTextField txtEmailID;
	JTextField txtAdminID;
	JPasswordField txtStuPwd;
	JPasswordField txtCnfStuPwd;
	JTextField txtPhone;


	Font font =new Font("Helvetica",Font.BOLD,24);
	Color DARKBLUE=new Color(0,0,64);
	Color FONTCOLOR=new Color(224,224,224);

	FileInputStream fis;
	DataInputStream dis;
	String saves[][] = new String [500][20];
	String records[][] = new String [500][20];
	int count = 0;
	int rows = 0;
	int total = 0;

	JButton btnSubmit;
	JButton btnCancel;

	public Register()
	{

		this.setTitle("Registration Form");
		JPanel panel=new JPanel();

		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbCons=new GridBagConstraints();

		gbCons.gridx=0;
		gbCons.gridy=0;
		lblHeading=new JLabel("Registration");
		lblHeading.setFont(font);
		lblHeading.setForeground(new Color(192,0,192));
		lblHeading.setVerticalAlignment(SwingConstants.TOP);
		gbCons.anchor=GridBagConstraints.EAST;
		panel.add(lblHeading,gbCons);



		gbCons.gridx=0;
		gbCons.gridy=1;
		lblAcctType=new JLabel("Account Type ");
		gbCons.anchor=GridBagConstraints.WEST;
		lblAcctType.setForeground(FONTCOLOR);
		panel.add(lblAcctType,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=1;
		String[] type={"Teacher","Student","Stuff"};
		lstAcctType = new JComboBox(type);
		lstAcctType.setSelectedIndex(1);
		panel.add(lstAcctType,gbCons);

		gbCons.gridx=0;
		gbCons.gridy=2;
		lblFirstName=new JLabel("First Name ");
		lblFirstName.setForeground(FONTCOLOR);
		panel.add(lblFirstName,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=2;
		txtFirstName=new JTextField(20);
		panel.add(txtFirstName,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=3;
		lblMidName=new JLabel("Middle Name ");
		lblMidName.setForeground(FONTCOLOR);
		panel.add(lblMidName,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=3;
		txtMidName=new JTextField(20);
		panel.add(txtMidName,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=4;
		lblLastName=new JLabel("Last Name ");
		lblLastName.setForeground(FONTCOLOR);
		panel.add(lblLastName,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=4;
		txtLastName=new JTextField(20);
		panel.add(txtLastName,gbCons);




		gbCons.gridx=0;
		gbCons.gridy=5;
		lblSex=new JLabel("Sex ");
		lblSex.setForeground(FONTCOLOR);
		panel.add(lblSex,gbCons);



		gbCons.gridx=1;
		gbCons.gridy=5;
		String[] sex={"Male","Female"};
		lstSex = new JComboBox(sex);
		lstSex.setSelectedIndex(0);
		panel.add(lstSex,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=6;
		lblAge=new JLabel("Age ");
		lblAge.setForeground(FONTCOLOR);
		panel.add(lblAge,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=6;
		txtAge=new JTextField(20);
		panel.add(txtAge,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=7;
		lblNationality=new JLabel("Nationality ");
		lblNationality.setForeground(FONTCOLOR);
		panel.add(lblNationality,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=7;
		txtNationality=new JTextField(20);
		panel.add(txtNationality,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=8;
		lblPreAddr=new JLabel("Present Address ");
		lblPreAddr.setForeground(FONTCOLOR);
		panel.add(lblPreAddr,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=8;
		txtPreAddr=new JTextField(20);
		panel.add(txtPreAddr,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=9;
		lblPerAddr=new JLabel("Permanent Address ");
		lblPerAddr.setForeground(FONTCOLOR);
		panel.add(lblPerAddr,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=9;
		txtPerAddr=new JTextField(20);
		panel.add(txtPerAddr,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=10;
		lblEmailID=new JLabel("Email Address ");
		lblEmailID.setForeground(FONTCOLOR);
		panel.add(lblEmailID,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=10;
		txtEmailID=new JTextField(20);
		panel.add(txtEmailID,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=11;
		lblAdminID=new JLabel("Admission ID ");
		lblAdminID.setForeground(FONTCOLOR);
		panel.add(lblAdminID,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=11;
		txtAdminID=new JTextField(20);
		panel.add(txtAdminID,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=12;
		lblStuPwd=new JLabel("Student Password ");
		lblStuPwd.setForeground(FONTCOLOR);
		panel.add(lblStuPwd,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=12;
		txtStuPwd=new JPasswordField(20);
		panel.add(txtStuPwd,gbCons);



		gbCons.gridx=0;
		gbCons.gridy=13;
		lblCnfStuPwd=new JLabel("Confirm Password ");
		lblCnfStuPwd.setForeground(FONTCOLOR);
		panel.add(lblCnfStuPwd,gbCons);



		gbCons.gridx=1;
		gbCons.gridy=13;
		txtCnfStuPwd=new JPasswordField(20);
		panel.add(txtCnfStuPwd,gbCons);


		gbCons.gridx=0;
		gbCons.gridy=14;
		lblPhone=new JLabel("Phone ");
		lblPhone.setForeground(FONTCOLOR);
		panel.add(lblPhone,gbCons);


		gbCons.gridx=1;
		gbCons.gridy=14;
		txtPhone=new JTextField(20);
		panel.add(txtPhone,gbCons);



		JPanel btnPanel=new JPanel();
		btnPanel.setBackground(DARKBLUE);
		btnSubmit=new JButton("Submit");
		btnPanel.add(btnSubmit);
		btnSubmit.addActionListener(this);


		btnCancel=new JButton("Cancel");
		btnPanel.add(btnCancel);
		btnCancel.addActionListener(this);


		gbCons.gridx=1;
		gbCons.gridy=15;
		gbCons.anchor=GridBagConstraints.EAST;
		panel.add(btnPanel,gbCons);

		panel.setBackground(DARKBLUE);

		getContentPane().add(panel);



		setVisible(true);
		setSize(450,450);

		setDefaultCloseOperation(EXIT_ON_CLOSE);


	}



	public void actionPerformed(ActionEvent e)
		{

				JButton button=(JButton)e.getSource();

				if(button.equals(btnCancel))
				{
					new HomePage();
					this.dispose();
				}

				else if(button.equals(btnSubmit))
				{

					int var=verify();

					if(var==1)
					{
						populateArray();
						findRec();
						this.dispose();
					}

					else
					{
						showErrordlg();
					}
				}
	}






		private int verify()
		{
			int ctr=0;
			int intAge=0;

			try{

					String frstName=txtFirstName.getText();

					String lstName=txtLastName.getText();
					String age=txtAge.getText();
					String nation=txtNationality.getText();
					String preAddr=txtPreAddr.getText();
					String parAddr=txtPerAddr.getText();




					String adminID=txtAdminID.getText();

					char[] usrPwd=txtStuPwd.getPassword();
					char[] cnfPwd=txtCnfStuPwd.getPassword();

					String strUsrPwd=new String(usrPwd);
					String strCnfPwd=new String(cnfPwd);
				try{
					 intAge=(int)Integer.parseInt(age.trim());
			}catch(Exception e){ }


					if((strUsrPwd.length()>0) &&
						(strCnfPwd.length()>0) &&
						(frstName.length()>0) &&

						(lstName.length()>0) &&
						(nation.length()>0) &&
						(preAddr.length()>0)&&
						(parAddr.length()>0)&&
						(intAge>18)&&(intAge<30)&&
						(adminID.length()>0) &&
						(strUsrPwd.equals(strCnfPwd)))
							{
								ctr=1;
								return ctr;

							}
		    }catch(Exception e){}


				return ctr;


				}





	private void populateArray()
	{


						try {
							fis = new FileInputStream ("Student.dat");
							dis = new DataInputStream (fis);

							while (true) {
								for (int i = 0; i < 20; i++) {
									records[rows][i] = dis.readUTF ();
								}
								rows++;
							}
						}

						catch (Exception ex) {
							total = rows;
							if (total == 0) { }
							else {
								try {
									dis.close();
									fis.close();
								}
								catch (Exception exp) { }
							}
						}

	}
	private void findRec()
	{
			boolean found = false;
						for (int x = 0; x < total; x++) {
							if (records[x][10].equals (txtAdminID.getText())) {
								found = true;
								JOptionPane.showMessageDialog (this, "Admission ID " + txtAdminID.getText () + " is Already Exist.",
											"BankSystem - WrongNo", JOptionPane.PLAIN_MESSAGE);
								txtClear ();
								break;
							}
						}
						if (found == false) {
							saveArray ();
			}
	}

		private void showErrordlg()
		{
					JOptionPane.showMessageDialog(this,"You didn't fill up all the Information!!!","Message",JOptionPane.ERROR_MESSAGE);


		}




	void saveArray () {




					char[] stuPwd=txtStuPwd.getPassword();
					String strPwd=new String(stuPwd);

					Calendar cal=Calendar.getInstance();


					String a=cal.get(Calendar.DATE)+"/"+(cal.get(Calendar.MONTH)+1)+"/"+cal.get(Calendar.YEAR);


					saves[count][0] = " "+lstAcctType.getSelectedItem ();
					saves[count][1] = txtFirstName.getText ();
					saves[count][2] = txtMidName.getText();
					saves[count][3] = txtLastName.getText();
					saves[count][4] = " "+lstSex.getSelectedItem();
					saves[count][5] = txtAge.getText ();
					saves[count][6]	= txtNationality.getText();
					saves[count][7]	= txtPreAddr.getText();
					saves[count][8]	= txtPerAddr.getText();
					saves[count][9]	= txtEmailID.getText();
					saves[count][10]= txtAdminID.getText();
					saves[count][11]= strPwd;
					saves[count][12]= txtPhone.getText();
					saves[count][13]= "NIL";
					saves[count][14]="NIL";
					saves[count][15]="NIL";
					saves[count][16]="NIL";
					saves[count][17]="NIL";
					saves[count][18]="NIL";
					saves[count][19]=a;

					saveFile ();
					count++;

				}

				void saveFile () {

					try {
						FileOutputStream fos = new FileOutputStream ("Student.dat", true);
						DataOutputStream dos = new DataOutputStream (fos);
						dos.writeUTF (saves[count][0]);
						dos.writeUTF (saves[count][1]);
						dos.writeUTF (saves[count][2]);
						dos.writeUTF (saves[count][3]);
						dos.writeUTF (saves[count][4]);
						dos.writeUTF (saves[count][5]);
						dos.writeUTF (saves[count][6]);
						dos.writeUTF (saves[count][7]);
						dos.writeUTF (saves[count][8]);
						dos.writeUTF (saves[count][9]);
						dos.writeUTF (saves[count][10]);
						dos.writeUTF (saves[count][11]);
						dos.writeUTF (saves[count][12]);
						dos.writeUTF (saves[count][13]);
						dos.writeUTF (saves[count][14]);
						dos.writeUTF (saves[count][15]);
						dos.writeUTF (saves[count][16]);
						dos.writeUTF (saves[count][17]);
						dos.writeUTF (saves[count][18]);
						dos.writeUTF (saves[count][19]);

						JOptionPane.showMessageDialog (this, "The Record has been Saved Successfully",
									"BankSystem - Record Saved", JOptionPane.PLAIN_MESSAGE);
						txtClear ();
						dos.close();
						fos.close();
					}
					catch (IOException ioe) {
						JOptionPane.showMessageDialog (this, "There are Some Problem with File",
									"BankSystem - Problem", JOptionPane.PLAIN_MESSAGE);
					}

				}

	void txtClear () {


			new Login();

	}


}