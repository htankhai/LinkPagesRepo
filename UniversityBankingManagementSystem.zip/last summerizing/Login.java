import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;




public class Login extends JFrame implements ActionListener
{

	JLabel lblStuID;
	JLabel lblStuPwd;
	JTextField txtStuID;
	JPasswordField txtStuPwd;
	JButton btnLogin;
	JButton btnCancel;
	Color DARKBLUE=new Color(0,0,64);
	Color FONTCOLOR=new Color(224,224,224);
	FileInputStream fis;
	FileOutputStream fos;
	DataOutputStream dos;
	DataInputStream dis;

	private int count = 0;
	private int rows = 0;
	private	int total = 0;


	private String records[][] = new String [500][20];




	public Login()
	{

		this.setTitle("Student Login Form");
		JPanel panel=new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbCons=new GridBagConstraints();
		gbCons.gridx=0;
		gbCons.gridy=0;
		lblStuID= new JLabel("Student ID ");
		lblStuID.setForeground(FONTCOLOR);
		panel.add(lblStuID,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=0;
		txtStuID= new JTextField(20);
		panel.add(txtStuID,gbCons);

		gbCons.gridx=0;
		gbCons.gridy=1;
		lblStuPwd= new JLabel("Password ");
		lblStuPwd.setForeground(FONTCOLOR);
		panel.add(lblStuPwd,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=1;
		txtStuPwd= new JPasswordField(20);
		panel.add(txtStuPwd,gbCons);


		JPanel btnPanel=new JPanel();
		btnPanel.setBackground(DARKBLUE);
		btnLogin=new JButton("View Account Details");
		btnPanel.add(btnLogin);
		btnLogin.addActionListener(this);


		btnCancel=new JButton("Cancel");
		btnPanel.add(btnCancel);
		btnCancel.addActionListener(this);

		gbCons.gridx=1;
		gbCons.gridy=3;
		gbCons.anchor=GridBagConstraints.EAST;
		panel.add(btnPanel,gbCons);

		panel.setBackground(DARKBLUE);

		getContentPane().add(panel);
		setVisible(true);
		setSize(450,200);


		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}




	public void actionPerformed(ActionEvent e)
	{

			JButton button=(JButton)e.getSource();

			if(button.equals(btnCancel))
			{
				new HomePage();
				this.dispose();
			}

			else
			{
				int var=verify();
				if(var==1)
				{

					rows = 0;
					populateArray ();
					findRec ();
					this.dispose();


				}
				else
				{

					JOptionPane.showMessageDialog(null,"You might forget to fill the ID or Password!!!","Warning",JOptionPane.ERROR_MESSAGE);

					new Login();
					this.dispose();


				}


			}

	}



	private	void populateArray () {

				try {
					fis = new FileInputStream ("Student.dat");
					dis = new DataInputStream (fis);

					while (true) {
						for (int i = 0; i < 20; i++) {
							records[rows][i] = dis.readUTF ();
						}
						rows++;
					}
				}
				catch (Exception ex) {
					total = rows;
					if (total == 0) {
						JOptionPane.showMessageDialog (null, "Records File is Empty.\nEnter Records First to Display.",
									"BankSystem - EmptyFile", JOptionPane.PLAIN_MESSAGE);

					}
					else {
						try {
							dis.close();
							fis.close();
						}
						catch (Exception exp) { }
					}
				}

			}

			void findRec () {

				boolean found = false;
				for (int x = 0; x < total; x++) {


					if (records[x][10].equals (txtStuID.getText())) {
						found = true;
						char [] pwd=txtStuPwd.getPassword();
						String str=new String(pwd);
						if(records[x][11].equals(str))
							new View (x);
						else
							{
								JOptionPane.showMessageDialog(null,"Invalid Password !!","ERROR",JOptionPane.ERROR_MESSAGE);
								new Login();
							}
						break;
					}


				}
				if (found == false) {
					JOptionPane.showMessageDialog (this, "Account No. " + txtStuID.getText () + " doesn't Exist.",
									"UniversityBankSystem - WrongNo", JOptionPane.PLAIN_MESSAGE);


					new Login();

				}

	}



	private int verify()
	{

		int ctrl=0;
		String ID=txtStuID.getText();
		char [] pwd=txtStuPwd.getPassword();
		String str=new String(pwd);


		if( (ID.length()>0)&& (str.length()>0) )
			{
				ctrl=1;
				return ctrl;
			}

		return ctrl;
	}

}