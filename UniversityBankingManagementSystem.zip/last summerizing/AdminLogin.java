import java.awt.*;
import javax.swing.*;
import java.awt.event.*;




public class AdminLogin extends JFrame implements ActionListener
{

	JLabel lblUserName;
	JLabel lblUserPwd;
	JTextField txtUserName;
	JPasswordField txtUserPwd;
	JButton btnLogin;

	JButton btnCancel;
	Color DARKBLUE=new Color(0,0,64);
	Color FONTCOLOR=new Color(224,224,224);




	public AdminLogin()
	{

		this.setTitle("Administrator");
		JPanel panel=new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbCons=new GridBagConstraints();
		gbCons.gridx=0;
		gbCons.gridy=0;
		lblUserName= new JLabel("User Name");
		lblUserName.setForeground(FONTCOLOR);
		panel.add(lblUserName,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=0;
		txtUserName= new JTextField(20);
		panel.add(txtUserName,gbCons);

		gbCons.gridx=0;
		gbCons.gridy=1;
		lblUserPwd= new JLabel("Password ");
		lblUserPwd.setForeground(FONTCOLOR);
		panel.add(lblUserPwd,gbCons);

		gbCons.gridx=1;
		gbCons.gridy=1;
		txtUserPwd= new JPasswordField(20);
		panel.add(txtUserPwd,gbCons);


		JPanel btnPanel=new JPanel();
		btnPanel.setBackground(DARKBLUE);
		btnLogin=new JButton("Login");
		btnPanel.add(btnLogin);
		btnLogin.addActionListener(this);

		btnCancel=new JButton("Cancel");
		btnPanel.add(btnCancel);
		btnCancel.addActionListener(this);

		gbCons.gridx=1;
		gbCons.gridy=3;
		gbCons.anchor=GridBagConstraints.CENTER;
		panel.add(btnPanel,gbCons);

		panel.setBackground(DARKBLUE);

		getContentPane().add(panel);
		setVisible(true);
		setSize(450,200);


		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}





	public void actionPerformed(ActionEvent e)
	{

			JButton button=(JButton)e.getSource();

			if(button.equals(btnCancel))
			{

				new HomePage();
				this.dispose();
			}
			else
			{



				int var=verify();
						if(var==1)
						{

							if(txtUserName.getText().equals("Administrator"))
								{
									char [] pwd=txtUserPwd.getPassword();
									String str=new String(pwd);
									if(str.equals("bank"))
										{
											new AdminPage();
											this.dispose();
										}
									else
									{
										JOptionPane.showMessageDialog(null,"You have enterd the wrong  Password!!!","Warning",JOptionPane.ERROR_MESSAGE);
										txtUserPwd.setText("");
									}
								}
							else
							{

								JOptionPane.showMessageDialog(null,"Invalid User Name","Warning",JOptionPane.ERROR_MESSAGE);
								txtUserName.setText("");
								txtUserPwd.setText("");
							}

						}
						else
							{
								JOptionPane.showMessageDialog(null,"You might forget to fill the ID or Password!!!","Warning",JOptionPane.ERROR_MESSAGE);
								txtUserPwd.setText("");
								new AdminLogin();
							}




				}


	}




		private int verify()
		{

			int ctrl=0;
			String ID=txtUserName.getText();
			char [] pwd=txtUserPwd.getPassword();
			String str=new String(pwd);


			if( (ID.length()>0)&& (str.length()>0) )
				{
					ctrl=1;
					return ctrl;
				}

			return ctrl;
	}

}