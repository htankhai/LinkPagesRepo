class prison_management_system
	{
		public static void main(String args[])
		{
			menu_screen m1 = new menu_screen();
			m1.setSize(760,600);
			m1.setVisible(true);
				
		}
	}

		