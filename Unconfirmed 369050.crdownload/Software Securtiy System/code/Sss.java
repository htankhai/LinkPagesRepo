// Source File Name:   Sss.java


class Sss
{

    Sss()
    {
    }

    public static void main(String args[])
    {
        FirstFrame firstframe = new FirstFrame("Software Security System");
    }
}