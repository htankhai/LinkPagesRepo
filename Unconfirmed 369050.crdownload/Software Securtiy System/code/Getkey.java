// Source File Name:   Sss.java


class Getkey
{

    Getkey()
    {
    }

    public String doit()
    {
        String s = new String();
        return s;
    }
}