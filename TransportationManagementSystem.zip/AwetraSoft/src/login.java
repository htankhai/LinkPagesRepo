 import javax.swing.*; 
import javax.swing.event.*;   
import java.awt.*; 
import java.awt.event.*; 
import java.sql.*;
 public class login extends JFrame   {
	 
       
	 JLabel username,password,forgotPassword,help;
	 static JTextField userText=new JTextField();
	 JPasswordField passText = new JPasswordField();
	 JButton LoginButton = new JButton("Login"); 
	 
	 JButton logOut = new JButton("Log out"); 
	
	 
         Connection conn =null; 
         ResultSet rs = null; 
         PreparedStatement pst = null; 
         Statement stmt; 
      
    
	 public login() throws Exception{
          initComponents(); 
//          conn = ODBC_class.getDBConnection(); //for ODBC
          conn = CreateDB.getConnection();
       
         }
          
         public void initComponents(){
          setTitle("Login Window");
		 setLayout(null);
//		 JLabel background = new JLabel(new ImageIcon(getClass().getResource("images/login.png")));
//		 setContentPane(background); 
		 
		 
		 //----------------------------------------------CONFIGURING LOGIN INTERFACE
		 username = new JLabel("User Name"); 
		 username.setFont(new Font("Verdana",Font.PLAIN,15));
		  userText.setFont(new Font("Verdana",Font.PLAIN,15));
                  userText.setBackground(Color.white); 
		 password = new JLabel("Password");  
		 password.setFont(new Font("Verdana",Font.PLAIN,15));
		   passText.setFont(new Font("Verdana",Font.PLAIN,15));
                   passText.setBackground(Color.white); 
		 forgotPassword = new JLabel("Forgot Password?"); 
		 forgotPassword.setFont(new Font ("Verdana",Font.PLAIN,10));
		 forgotPassword.addMouseListener( new MouseListener(){

                        
			@Override
			public void mouseClicked(MouseEvent e) {
				forgotPassword.setForeground(Color.red); 
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				forgotPassword.setForeground(Color.blue); 
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				forgotPassword.setForeground(Color.black); 
				
			}
			 
		 });
		
		 help = new JLabel ("Help!");
		 help.addMouseListener( new MouseListener(){

				@Override
				public void mouseClicked(MouseEvent e) {
					help.setForeground(Color.red); 
                                        help.setToolTipText("Please click on \"Forgot Password\" to help you retrieve your password.");
                                        
					
				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseEntered(MouseEvent e) {
					help.setForeground(Color.blue); 
					
				}

				@Override
				public void mouseExited(MouseEvent e) {
					
					help.setForeground(Color.black.brighter()); 
					
				}
				 
			 });
		 help.setFont(new Font ("Verdana",Font.PLAIN,10));
		 
		 Insets margin = new Insets(5,1,5,1);
		 LoginButton.setMargin(margin);
		 
               userText.addFocusListener(new FocusListener(){

              @Override
              public void focusGained(FocusEvent e) {
                 userText.setBackground(Color.white); 
              }

              @Override
              public void focusLost(FocusEvent e) {
                  
              }
                   
               });
               
               passText.addFocusListener(new FocusListener(){

              @Override
              public void focusGained(FocusEvent e) {
                  passText.setBackground(Color.white);
                  
              }

              @Override
              public void focusLost(FocusEvent e) {
                 
              }
                   
               }); 
	 
		 	 
		//----------------------------------------------SETTING BOUNDS
		 username.setBounds(15,25,150,30); 
		 userText.setBounds(110,25,200,30);
		 password.setBounds(15,70,150,30); 
		 passText.setBounds(110,70,200,30);
		 forgotPassword.setBounds(110,110,100,30); 
		 help.setBounds(280,110,100,30); 
		 LoginButton.setBounds(245,150,65,30);
		 logOut.setBounds(110,150,90,30); 
		 add(username); 
		 add(userText); 
		 add(password);
		 add(passText); 
		 add(forgotPassword); 
		 add(help); 
		 add(logOut); 
		 add(LoginButton); 
		 
		 LoginButton.addActionListener(new ActionListener(){
			public void actionPerformed (ActionEvent event){
				 
                                    String sql = "SELECT * FROM login where UserName=? and Password=?";
                                    try{
                                   pst=conn.prepareStatement(sql); 
                                   pst.setString(1,userText.getText());
                                   pst.setString(2,passText.getText());
                                   
                                   rs = pst.executeQuery();
                                   if (userText.getText().equals(rs.getString("UserName"))&& passText.getText().equals(rs.getString("Password"))){
                                       
                                   if(rs.next()){
                                       JOptionPane.showMessageDialog(null,"Successfully Logged in!");
                                       
                                       StartPage frame = new StartPage(); 
                                       frame.pack(); 
                                       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                                       frame.setVisible(true ); 
                                       
                                       dispose(); 
                                   }
                                   }
                                   else{
                                       userText.setBackground(Color.pink); 
                                       passText.setBackground(Color.pink); 
                                       JOptionPane.showMessageDialog(null,"Wrong UserName or Password!");
                                   }
                                    
                                    }catch(Exception e){
                                         JOptionPane.showMessageDialog(null,"COULD NOT CONNECT TO DATABASE", "ERROR",JOptionPane.ERROR_MESSAGE);
                                    }
                             
				 
			}
		 });        
                 
               logOut.addActionListener(new ActionListener(){
                   public void actionPerformed(ActionEvent event){
                       dispose(); 
                       
                   }
               });
               
               passText.addActionListener(new ActionListener(){
                   public void actionPerformed(ActionEvent event){
                       
                                    String sql = "SELECT * FROM login where UserName=? and Password=?";
                                    try{
                                   pst=conn.prepareStatement(sql); 
                                   pst.setString(1,userText.getText());
                                   
                                   pst.setString(2,passText.getText());
                                   
                                       rs = pst.executeQuery(); 
                                      if(rs.next()){
                                       JOptionPane.showMessageDialog(null,"Successfully Logged in!");
                                       
                                       StartPage frame = new StartPage(); 
                                       frame.pack(); 
                                       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                                       frame.setVisible(true ); 
                                       dispose(); 
                                   }
                                   else{
                                       userText.setBackground(Color.pink); 
                                       passText.setBackground(Color.pink); 
                                       JOptionPane.showMessageDialog(null,"Wrong UserName or Password!");
                                   }
                                           
                                
                                    
                                    }catch(Exception e){
                                         JOptionPane.showMessageDialog(null,"COULD NOT CONNECT TO DATABASE", "ERROR",JOptionPane.ERROR_MESSAGE);
                                    }
                             
				 
			
                   }
               });
               
         }
       
	
	
	 
 }
 