import java.io.*;
import java.net.*; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

public class Server extends JFrame{

	private JTextField userText;
	private JTextArea chatWindow;
	private ObjectOutputStream output; 
	private ObjectInputStream input; 
	private ServerSocket server; 
	private Socket connection; //connection between you and another computer
	
	public Server(){
		super ("AwetraSoft Chat_Server");
		userText = new JTextField();
		userText.setEditable(false);
		
		userText.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				sendMessage(event.getActionCommand());
				userText.setText("");
				
			}
		});
		add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextArea(); 
		chatWindow.setEditable(false);
		add(new JScrollPane(chatWindow));
		setSize(300,150); 
		setVisible(true);
             
	}
	/********************************************************SET UP AND RUN THE SERVER */
	public void startRunning(){
		try{
			server = new ServerSocket(3306,5);
			while(true){
				try{
					/***************************************CONNECT AND HAVE CONVERSATION */
					waitForConnection();
					setupStreams();
					whileChatting();
					
				}catch(EOFException eofException){
					showMessage("\nServer ended the connection! ");
				}finally{
				closeCrap();
			}
			}
		}catch(IOException ioException){ 
			ioException.printStackTrace();
		}
	}
	
	/****************************************************** WAIT FOR CONNECTION AND DISPLAY CONNECTION INFO */
	private void waitForConnection()throws IOException{
		showMessage("Waiting for someone to connect...\n");
		connection = server.accept(); //Listens and accepts a connection
		showMessage("Now connected to "+connection.getInetAddress()); //getInetAddress returns address to which socket is connected
		
	}
	/***************************************************** GET STREAM TO SEND AND RECEIVE DATA */
	private void setupStreams()throws IOException{
		output = new ObjectOutputStream(connection.getOutputStream());//getOutputStream returns output stream for this socket
		output.flush();
		input = new ObjectInputStream (connection.getInputStream()); //getInputStream returns input stream for this socket
		showMessage("\nStreams are now setup!\n");
	}
	//during chat conversation
	private void whileChatting()throws IOException{
		String message ="You are now connected!";
		sendMessage(message);
		ableToType(true);
		do{
			try{
				 message =(String)input.readObject(); 
				showMessage("\n "+message);
 
			}catch(ClassNotFoundException classNotFoundException){
				showMessage("\nOops, this can't be processed!");
			}
		}while(!message.equals("CLIENT-END"));
	}
	/**************************************************** CLOSE STREAMS AND SOCKETS AFTER YOU ARE DONE CHATTING */
	private void closeCrap(){
		showMessage("\nClosing Connection...\n");
		ableToType(false);
		try {
			output.close();
			input.close();
			connection.close();
		}catch(IOException ioException){
			ioException.printStackTrace();
		}
	}
	/************************************************* SEND A MESSAGE TO CLIENT */
	private void sendMessage(String message){
		try{
			output.writeObject("SERVER - "+message);
			output.flush();
			showMessage("\nSERVER - "+ message);
		}catch(IOException ioException){
			chatWindow.append("\n ERROR: CAN'T SEND THAT MESSAGE");
		}
	}
	/*********************************************** UPDATES CHATWINDOW */
	private void showMessage(final String text){
		SwingUtilities.invokeLater(
			new Runnable(){
				public void run(){
					chatWindow.append(text);
				}
			}
		);
	}
		
	private void ableToType(final boolean tof){
		SwingUtilities.invokeLater(
			new Runnable(){
				public void run(){
					userText.setEditable(tof); 
				}
			}
		);
	}
}
