

import java.applet.AppletContext;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.print.PrinterJob;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.*; 
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random; 
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Elipics
 */
public class StartPage extends javax.swing.JFrame {

    /**
     * Creates new form StartPage
     * 
     * 
     * 
     */
    
    private Statement stmt; 
    Connection conn; 
    ResultSet rst; 


    BusEntry be; 
       PreparedStatement pst = null; 
    
    
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    public void clock(){
        Thread clock = new Thread()
        {
            public void run()
            {
                try{
                    while(true){
                    Calendar cal = new GregorianCalendar(); 
        int day = cal.get(Calendar.DAY_OF_MONTH); 
        int month = cal.get(Calendar.MONTH); 
        int year = cal.get(Calendar.YEAR); 
        
        int second = cal.get(Calendar.SECOND); 
        int minute = cal.get(Calendar.MINUTE); 
        int hour = cal.get(Calendar.HOUR); 
        clockLabel.setText("Time "+hour+":"+minute+":"+second+" Date "+year+"/"+month+"/"+day);
                    sleep(1000);
                    }
                }catch (InterruptedException e){
                    e.printStackTrace(); 
                }
                
                
            }
        };
        clock.start(); 
        
    }
    private void EnableOrDisable(){
        if (Login_Window.positionCombo.getSelectedItem()== "Superviser"){
           newUser.setEnabled(false);
            btmv.setEnabled(false);
             TicketOperation.setEnabled(false);
        }else if (Login_Window.positionCombo.getSelectedItem()=="Booking Clerk"){
            newUser.setEnabled(false);
            view.setEnabled(false);
            addDriverMenu.setEnabled(false);
            MR.setEnabled(false);
        }
        else if (Login_Window.positionCombo.getSelectedItem()=="Secretary"){
            newUser.setEnabled(false);
            MR.setEnabled(false);
            addDriverMenu.setEnabled(false);
        }
        ButtonGroup group =new ButtonGroup(); 
        group.add(show);
        group.add(hide);
    }
    
    private void showUserRec(){
        
        try{
            conn = CreateDB.getConnection(); 
            String sql = "select * from login where UserName ='"+Login_Window.userText.getText()+"'"; 
            pst=conn.prepareStatement(sql); 
            rst=pst.executeQuery(); 
            if (rst.next()){
//            byte[]imagedata = rst.getBytes("Image"); 
//            ImageIcon format = new ImageIcon(imagedata); 
//            UserPic.setIcon(format); 
//            name.setText(login.userText.getText()); 
           
              byte[]imagedata = rst.getBytes("Image"); 
              if(rst.getBytes("Image")!=null){
            ImageIcon format = new ImageIcon(imagedata); 
             Image img = format.getImage();
              Image newImage = img.getScaledInstance(UserPic.getWidth(), UserPic.getHeight(),Image.SCALE_SMOOTH);
               ImageIcon pic = new ImageIcon(newImage);
               
                 UserPic.setIcon(pic);
                 name.setText(rst.getString("UserName"));
                  position.setText(rst.getString("Position")); 
              }else{
                       name.setText(rst.getString("UserName"));
                  position.setText(rst.getString("Position")); 
              }
            }
            }
            catch(SQLException e)
            {
           JOptionPane.showMessageDialog(this,e.getMessage()); 
            
            }
    }
    
      public void windowClosing(WindowEvent e) {
        ConfirmExit();
       
    }
    public StartPage() {
        
        initComponents();
        conn=CreateDB.getConnection(); 
        EnableOrDisable();
        clock(); 
        showUserRec();
       
        
            ImageIcon imageIcon = new ImageIcon("LOGO.gif");
        setIconImage(imageIcon.getImage());
        
        
//        Image image = Toolkit.getDefaultToolkit().getImage("LOGO.gif");
//         MediaTracker tracker = new MediaTracker(this);
//        tracker.addImage(image,0);
//        try {
//            tracker.waitForID(0);
//        }
//        catch(Exception e) {
//            System.out.println(e);
//        }        
//
//        setIconImage(image);

    
        


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jPopupMenu3 = new javax.swing.JPopupMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        HomePanel = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        clockLabel = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        UserPic = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        position = new javax.swing.JLabel();
        HomeWindowTabs = new javax.swing.JTabbedPane();
        startPanel = new javax.swing.JPanel();
        themeBut = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        themeBut1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        AccraLabel = new javax.swing.JLabel();
        CapeLabel = new javax.swing.JLabel();
        KumasiLabel = new javax.swing.JLabel();
        SunyaniLabel = new javax.swing.JLabel();
        BolgaLabel = new javax.swing.JLabel();
        WaLabel = new javax.swing.JLabel();
        HoLabel = new javax.swing.JLabel();
        KoforiduaLabel = new javax.swing.JLabel();
        TakoradiLabel = new javax.swing.JLabel();
        TamaleLabel = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        TablePanel = new javax.swing.JPanel();
        btnPrint = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnAddNew = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        TickPanel = new javax.swing.JPanel();
        TicketPanel = new javax.swing.JPanel();
        tickNoPlate = new javax.swing.JTextField();
        tickDate = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        tickFare = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        serNo = new javax.swing.JTextField();
        txtTickFrom = new javax.swing.JTextField();
        tickTo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        GenBut = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        file = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        newUser = new javax.swing.JMenuItem();
        addDriverMenu = new javax.swing.JMenuItem();
        btmv = new javax.swing.JMenuItem();
        TicketOperation = new javax.swing.JMenuItem();
        MR = new javax.swing.JMenuItem();
        view = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        show = new javax.swing.JRadioButtonMenuItem();
        hide = new javax.swing.JRadioButtonMenuItem();
        jMenu5 = new javax.swing.JMenu();
        menuKbs = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        about = new javax.swing.JMenuItem();

        jPanel2.setBackground(new java.awt.Color(252, 252, 252));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jPanel3.setBackground(new java.awt.Color(96, 125, 245));

        jButton6.setText("jButton6");
        jButton6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("jButton6");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("jButton6");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("jButton6");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setText("jButton6");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(291, Short.MAX_VALUE))
        );

        jMenuItem1.setText("jMenuItem1");

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        jPopupMenu3.setBackground(new java.awt.Color(51, 0, 204));
        jPopupMenu3.setBorder(javax.swing.BorderFactory.createTitledBorder("Pop Message"));
        jPopupMenu3.setEnabled(false);

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Transport Management System");
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(37, 99, 145), new java.awt.Color(37, 99, 145), null, null));
        jPanel11.setAlignmentX(500.0F);
        jPanel11.setAlignmentY(250.0F);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MMT LOGO.jpg"))); // NOI18N
        jLabel16.setToolTipText("MMT Logo");
        jLabel16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel10.setFont(new java.awt.Font("Georgia", 0, 13)); // NOI18N
        jLabel10.setText("Name: ");

        jLabel13.setFont(new java.awt.Font("Georgia", 0, 13)); // NOI18N
        jLabel13.setText("Position: ");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        UserPic.setMaximumSize(new java.awt.Dimension(107, 120));
        UserPic.setMinimumSize(new java.awt.Dimension(107, 120));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(UserPic, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(UserPic, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        name.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        position.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(position, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(clockLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(position, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        HomeWindowTabs.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        HomeWindowTabs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HomeWindowTabsMouseClicked(evt);
            }
        });

        startPanel.setBackground(new java.awt.Color(255, 255, 255));
        startPanel.setEnabled(false);
        startPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                startPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                startPanelMouseEntered(evt);
            }
        });
        startPanel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                startPanelKeyTyped(evt);
            }
        });

        themeBut.setBackground(new java.awt.Color(255, 153, 0));

        jLabel4.setFont(new java.awt.Font("Lucida Calligraphy", 0, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("...moving the nation");

        javax.swing.GroupLayout themeButLayout = new javax.swing.GroupLayout(themeBut);
        themeBut.setLayout(themeButLayout);
        themeButLayout.setHorizontalGroup(
            themeButLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, themeButLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        themeButLayout.setVerticalGroup(
            themeButLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, themeButLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(21, 21, 21))
        );

        themeBut1.setBackground(new java.awt.Color(255, 153, 0));
        themeBut1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                themeBut1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout themeBut1Layout = new javax.swing.GroupLayout(themeBut1);
        themeBut1.setLayout(themeBut1Layout);
        themeBut1Layout.setHorizontalGroup(
            themeBut1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        themeBut1Layout.setVerticalGroup(
            themeBut1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 62, Short.MAX_VALUE)
        );

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/routesandfares.jpg"))); // NOI18N

        AccraLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        AccraLabel.setText("Greater Accra");
        AccraLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AccraLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AccraLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AccraLabelMouseExited(evt);
            }
        });

        CapeLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        CapeLabel.setText("Cape Coast");
        CapeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CapeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CapeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CapeLabelMouseExited(evt);
            }
        });

        KumasiLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        KumasiLabel.setText("Kumasi");
        KumasiLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KumasiLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                KumasiLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                KumasiLabelMouseExited(evt);
            }
        });

        SunyaniLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        SunyaniLabel.setText("Sunyani");
        SunyaniLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SunyaniLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SunyaniLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SunyaniLabelMouseExited(evt);
            }
        });

        BolgaLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        BolgaLabel.setText("Bolgatanga");
        BolgaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BolgaLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BolgaLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BolgaLabelMouseExited(evt);
            }
        });

        WaLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        WaLabel.setText("Wa");
        WaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                WaLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                WaLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                WaLabelMouseExited(evt);
            }
        });

        HoLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        HoLabel.setText("Ho");
        HoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HoLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                HoLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                HoLabelMouseExited(evt);
            }
        });

        KoforiduaLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        KoforiduaLabel.setText("Koforidua");
        KoforiduaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KoforiduaLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                KoforiduaLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                KoforiduaLabelMouseExited(evt);
            }
        });

        TakoradiLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        TakoradiLabel.setText("Takoradi");
        TakoradiLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TakoradiLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TakoradiLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TakoradiLabelMouseExited(evt);
            }
        });

        TamaleLabel.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        TamaleLabel.setText("Tamale");
        TamaleLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TamaleLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TamaleLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TamaleLabelMouseExited(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Monotype Corsiva", 1, 22)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(33, 99, 145));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/features.jpg"))); // NOI18N

        jLabel23.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel23.setText("This program allows you to easily access every feature with the ");

        jLabel24.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel24.setText("help of displayed tab. AweSoft MMT also allows you to print");

        jLabel25.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel25.setText("\"Car Info\" data. AweSoft MMt has also made provision for a notepad");

        jLabel26.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel26.setText("and calculator in the menu\"Tools\" on the menu bar. For more features and ");

        jLabel27.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel27.setText("help click on \"Help\" on the menu Bar.");

        javax.swing.GroupLayout startPanelLayout = new javax.swing.GroupLayout(startPanel);
        startPanel.setLayout(startPanelLayout);
        startPanelLayout.setHorizontalGroup(
            startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(themeBut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(themeBut1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(startPanelLayout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AccraLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(HoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KoforiduaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TakoradiLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TamaleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(WaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SunyaniLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BolgaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CapeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(KumasiLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(26, 26, 26))
        );
        startPanelLayout.setVerticalGroup(
            startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(startPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(themeBut1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AccraLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(CapeLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(KumasiLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(SunyaniLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BolgaLabel)
                    .addComponent(jLabel27))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(WaLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(KoforiduaLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TakoradiLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TamaleLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 186, Short.MAX_VALUE)
                .addComponent(themeBut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        HomeWindowTabs.addTab("Start ", new javax.swing.ImageIcon(getClass().getResource("/images/start.jpg")), startPanel); // NOI18N

        TablePanel.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N

        btnPrint.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/print.png"))); // NOI18N
        btnPrint.setText("Print");
        btnPrint.setToolTipText("Make a print of this data.");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        btnRefresh.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/refresh.JPG"))); // NOI18N
        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnUpdate.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Update....JPG"))); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.setToolTipText("Update bus entries using this button.");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnAddNew.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnAddNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addnew....JPG"))); // NOI18N
        btnAddNew.setText("Add New");
        btnAddNew.setToolTipText("Add new bus entries using this button");
        btnAddNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNewActionPerformed(evt);
            }
        });

        jScrollPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        table.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Bus No.", "Bus No. Plate", "Model", "Capcity", "Date Purchased", "Insurance Status", "Date Insured", "Expiry Date"
            }
        ));
        table.setEnabled(false);
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout TablePanelLayout = new javax.swing.GroupLayout(TablePanel);
        TablePanel.setLayout(TablePanelLayout);
        TablePanelLayout.setHorizontalGroup(
            TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TablePanelLayout.createSequentialGroup()
                .addContainerGap(474, Short.MAX_VALUE)
                .addComponent(btnAddNew)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrint)
                .addGap(18, 18, 18))
            .addGroup(TablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        TablePanelLayout.setVerticalGroup(
            TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                .addGroup(TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPrint)
                    .addComponent(btnRefresh)
                    .addComponent(btnUpdate)
                    .addComponent(btnAddNew)))
        );

        HomeWindowTabs.addTab("Vehicle Infomation", new javax.swing.ImageIcon(getClass().getResource("/images/carinfopic.JPG")), TablePanel); // NOI18N

        TicketPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        tickNoPlate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tickNoPlate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tickNoPlateActionPerformed(evt);
            }
        });

        tickDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        jLabel1.setText("           METRO MASS TRANSIT SERVICE");

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("No. Plate");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("DATE");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("FROM");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("TO");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("FARE");

        tickFare.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("S. NO.");

        serNo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        serNo.setEnabled(false);
        serNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serNoActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/MMT LOGO.jpg"))); // NOI18N

        javax.swing.GroupLayout TicketPanelLayout = new javax.swing.GroupLayout(TicketPanel);
        TicketPanel.setLayout(TicketPanelLayout);
        TicketPanelLayout.setHorizontalGroup(
            TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(TicketPanelLayout.createSequentialGroup()
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(tickFare, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE))
                                .addGroup(TicketPanelLayout.createSequentialGroup()
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtTickFrom)))
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tickNoPlate, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(tickTo, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE))
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(3, 3, 3)
                                .addComponent(tickDate))
                            .addGroup(TicketPanelLayout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(serNo))))
                    .addGroup(TicketPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)))
                .addGap(14, 14, 14))
        );
        TicketPanelLayout.setVerticalGroup(
            TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tickDate, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tickNoPlate, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTickFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tickTo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tickFare)
                    .addGroup(TicketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(serNo, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                        .addComponent(jLabel9)))
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(TicketPanelLayout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        GenBut.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        GenBut.setText("Generate");
        GenBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenButActionPerformed(evt);
            }
        });

        jButton1.setText("Print");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TickPanelLayout = new javax.swing.GroupLayout(TickPanel);
        TickPanel.setLayout(TickPanelLayout);
        TickPanelLayout.setHorizontalGroup(
            TickPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TickPanelLayout.createSequentialGroup()
                .addGroup(TickPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TickPanelLayout.createSequentialGroup()
                        .addGap(505, 505, 505)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(GenBut))
                    .addGroup(TickPanelLayout.createSequentialGroup()
                        .addGap(186, 186, 186)
                        .addComponent(TicketPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(216, Short.MAX_VALUE))
        );
        TickPanelLayout.setVerticalGroup(
            TickPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TickPanelLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(TicketPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addGroup(TickPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GenBut)
                    .addComponent(jButton1))
                .addContainerGap(184, Short.MAX_VALUE))
        );

        HomeWindowTabs.addTab("Ticket", TickPanel);

        javax.swing.GroupLayout HomePanelLayout = new javax.swing.GroupLayout(HomePanel);
        HomePanel.setLayout(HomePanelLayout);
        HomePanelLayout.setHorizontalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(HomeWindowTabs)
                .addContainerGap())
        );
        HomePanelLayout.setVerticalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(HomeWindowTabs)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        menuBar.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N

        file.setText("File");
        file.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit.JPG"))); // NOI18N
        jMenuItem2.setText("Exit");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        file.add(jMenuItem2);

        menuBar.add(file);

        jMenu4.setText("Operations");
        jMenu4.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        newUser.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        newUser.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        newUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addUser.JPG"))); // NOI18N
        newUser.setText("New User");
        newUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newUserActionPerformed(evt);
            }
        });
        jMenu4.add(newUser);

        addDriverMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        addDriverMenu.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        addDriverMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addDriver.JPG"))); // NOI18N
        addDriverMenu.setText("Add Driver");
        addDriverMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDriverMenuActionPerformed(evt);
            }
        });
        jMenu4.add(addDriverMenu);

        btmv.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        btmv.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btmv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/book.JPG"))); // NOI18N
        btmv.setText("Book Movements");
        btmv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmvActionPerformed(evt);
            }
        });
        jMenu4.add(btmv);

        TicketOperation.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        TicketOperation.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        TicketOperation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ticket.JPG"))); // NOI18N
        TicketOperation.setText("Sell Ticket");
        TicketOperation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TicketOperationActionPerformed(evt);
            }
        });
        jMenu4.add(TicketOperation);

        MR.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        MR.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        MR.setText("Master Reset");
        MR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MRActionPerformed(evt);
            }
        });
        jMenu4.add(MR);

        menuBar.add(jMenu4);

        view.setText("View");
        view.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jMenuItem5.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/driverDetails.JPG"))); // NOI18N
        jMenuItem5.setText("Driver Details");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        view.add(jMenuItem5);

        jMenuItem9.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        jMenuItem9.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/movDetails.JPG"))); // NOI18N
        jMenuItem9.setText("Movement Details");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        view.add(jMenuItem9);

        jMenuItem13.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        jMenuItem13.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/soldout.JPG"))); // NOI18N
        jMenuItem13.setText("Tickets Sold");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        view.add(jMenuItem13);

        menuBar.add(view);

        jMenu6.setText("Tools");
        jMenu6.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem7.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem7.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/calc.PNG"))); // NOI18N
        jMenuItem7.setText("Calculator");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem7);

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem8.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/notepad.JPG"))); // NOI18N
        jMenuItem8.setText("Notepad");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem8);

        menuBar.add(jMenu6);

        jMenu8.setText("Window");
        jMenu8.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenu3.setText("Theme");
        jMenu3.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem11.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuItem11.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/yingtheme.JPG"))); // NOI18N
        jMenuItem11.setText("Color");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem11);

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F10, 0));
        jMenuItem6.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem6.setText("Nimbus");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuItem12.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem12.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem12.setText("Windows Theme");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem12);

        jMenu8.add(jMenu3);

        show.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        show.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        show.setSelected(true);
        show.setText("Show");
        show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showActionPerformed(evt);
            }
        });
        jMenu8.add(show);

        hide.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        hide.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        hide.setSelected(true);
        hide.setText("Hide");
        hide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideActionPerformed(evt);
            }
        });
        jMenu8.add(hide);

        menuBar.add(jMenu8);

        jMenu5.setText("Help");
        jMenu5.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        menuKbs.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        menuKbs.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        menuKbs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/kbs.JPG"))); // NOI18N
        menuKbs.setText("Keyboard Shortcuts");
        menuKbs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuKbsActionPerformed(evt);
            }
        });
        jMenu5.add(menuKbs);
        jMenu5.add(jSeparator2);

        about.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F11, 0));
        about.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        about.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/help.JPG"))); // NOI18N
        about.setText("About");
        about.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutActionPerformed(evt);
            }
        });
        jMenu5.add(about);

        menuBar.add(jMenu5);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(HomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(HomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
 String ActCmd = evt.getActionCommand();
                
       if (ActCmd.equalsIgnoreCase("exit")) {
                ConfirmExit();
       
     
       
       }
       
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btnAddNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNewActionPerformed
        BusEntry Bus_Entry = new BusEntry();
     
        try{   
            Bus_Entry.setLocation(400,300);
            Bus_Entry.setVisible(true);
        }catch(Exception e){
               
        }
    }//GEN-LAST:event_btnAddNewActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
     
        reloaded(); 
      
       
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void tickNoPlateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tickNoPlateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tickNoPlateActionPerformed

    private void GenButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenButActionPerformed
  int random =10000000 + (int)(Math.random()*10000000);
        serNo.setText(String.valueOf(random));
        
    }//GEN-LAST:event_GenButActionPerformed

    private void startPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startPanelMouseClicked
     count=0; 
    }//GEN-LAST:event_startPanelMouseClicked

    private void HomeWindowTabsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeWindowTabsMouseClicked
        count=0; 
        reloaded(); 
    }//GEN-LAST:event_HomeWindowTabsMouseClicked

    private void startPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startPanelMouseEntered
        // TODO add your handling code here:
        count=0; 
    }//GEN-LAST:event_startPanelMouseEntered

    private void serNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_serNoActionPerformed

    private void themeBut1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_themeBut1MouseClicked
          count++;
        if (count==4){
         
            String ObjButtons[] = {"Yes", "No"};
            int PromptResult = JOptionPane.showOptionDialog(null, "Entering chat session?",
                "ATTENTION!", JOptionPane.INFORMATION_MESSAGE, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
            if (PromptResult == 0) {

                ChatLogin Cl = new ChatLogin(); 
                Cl.pack();
                Cl.setLocation(400,300);
                Cl.setVisible(true);
                Cl.setResizable(false);
                Cl.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                
            } else {

            }

            count=0;
    }//GEN-LAST:event_themeBut1MouseClicked
    }
    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
//        TextEditor notepad = new TextEditor(); 
//        notepad.setSize(600,500);
//        notepad.setVisible(true);
        
             String ActCmd = evt.getActionCommand();
            if (ActCmd.equalsIgnoreCase("notepad")) {
                try {
                    Runtime.getRuntime().exec("notepad.exe");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error,Cannot start calculator", "Applicaton Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
			PrinterJob pj = PrinterJob.getPrinterJob();
			boolean print=true;
		if(print){
		try {
			table.print();
		} catch (Exception e2) {
			
		}	
		
		}

    }//GEN-LAST:event_btnPrintActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
       String ActCmd = evt.getActionCommand();
            if (ActCmd.equalsIgnoreCase("calculator")) {
                try {
                    Runtime.getRuntime().exec("calc.exe");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error,Cannot start calculator", "Applicaton Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void menuKbsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuKbsActionPerformed
        javax.swing.JFrame kbs = new KeyBoardshortcuts(); 
        kbs.pack(); 
        kbs.setLocation(400,150);
        kbs.setVisible(true);
        kbs.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        kbs.setAlwaysOnTop(true);
    }//GEN-LAST:event_menuKbsActionPerformed

    private void AccraLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccraLabelMouseClicked
  
       try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/gt_accra.htm"));
                } catch (URISyntaxException | IOException ex) {
    
                }
       
    }//GEN-LAST:event_AccraLabelMouseClicked

    private void AccraLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccraLabelMouseEntered

        AccraLabel.setText("<html><a href=\"\">Greater Accra</a></html>");
    
        
     
    }//GEN-LAST:event_AccraLabelMouseEntered

    private void AccraLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccraLabelMouseExited
        AccraLabel.setText("Greater Accra");
    }//GEN-LAST:event_AccraLabelMouseExited

    private void CapeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CapeLabelMouseClicked
       
       try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/central.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_CapeLabelMouseClicked

    private void KumasiLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KumasiLabelMouseClicked
      try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/ashanti.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_KumasiLabelMouseClicked

    private void SunyaniLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SunyaniLabelMouseClicked
              try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/brong_hafo.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_SunyaniLabelMouseClicked

    private void BolgaLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BolgaLabelMouseEntered
            BolgaLabel.setText("<html><a href=\"\">Bolgatanga</a></html>");
    }//GEN-LAST:event_BolgaLabelMouseEntered

    private void BolgaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BolgaLabelMouseClicked
           try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/upper_east.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_BolgaLabelMouseClicked

    private void WaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_WaLabelMouseClicked
          try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/upper_west.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_WaLabelMouseClicked

    private void HoLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HoLabelMouseClicked
           try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/volta_region.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_HoLabelMouseClicked

    private void KoforiduaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KoforiduaLabelMouseClicked
         try {
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/eastern_region.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_KoforiduaLabelMouseClicked

    private void TakoradiLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TakoradiLabelMouseClicked
       try{
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/western.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_TakoradiLabelMouseClicked

    private void TamaleLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TamaleLabelMouseClicked
         try{
                    Desktop.getDesktop().browse(new URI("http://www.metromass.com/mmt/northern.htm"));
                } catch (URISyntaxException | IOException ex) {
                    //It looks like there's a problem
                }
    }//GEN-LAST:event_TamaleLabelMouseClicked

    private void CapeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CapeLabelMouseEntered
           CapeLabel.setText("<html><a href=\"\">Cape Coast</a></html>");
    }//GEN-LAST:event_CapeLabelMouseEntered

    private void KumasiLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KumasiLabelMouseEntered
           KumasiLabel.setText("<html><a href=\"\">Kumasi</a></html>");
    }//GEN-LAST:event_KumasiLabelMouseEntered

    private void SunyaniLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SunyaniLabelMouseEntered
            SunyaniLabel.setText("<html><a href=\"\">Sunyani</a></html>");
    }//GEN-LAST:event_SunyaniLabelMouseEntered

    private void WaLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_WaLabelMouseEntered
          WaLabel.setText("<html><a href=\"\">Wa</a></html>");
    }//GEN-LAST:event_WaLabelMouseEntered

    private void HoLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HoLabelMouseEntered
   HoLabel.setText("<html><a href=\"\">Ho</a></html>");
    }//GEN-LAST:event_HoLabelMouseEntered

    private void KoforiduaLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KoforiduaLabelMouseEntered
   KoforiduaLabel.setText("<html><a href=\"\">Koforidua</a></html>");
    }//GEN-LAST:event_KoforiduaLabelMouseEntered

    private void TakoradiLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TakoradiLabelMouseEntered
      TakoradiLabel.setText("<html><a href=\"\">Takoradi</a></html>");
    }//GEN-LAST:event_TakoradiLabelMouseEntered

    private void TamaleLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TamaleLabelMouseEntered
   TamaleLabel.setText("<html><a href=\"\">Tamale</a></html>");
    }//GEN-LAST:event_TamaleLabelMouseEntered

    private void TamaleLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TamaleLabelMouseExited
      TamaleLabel.setText("Tamale");
    }//GEN-LAST:event_TamaleLabelMouseExited

    private void TakoradiLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TakoradiLabelMouseExited
   TakoradiLabel.setText("Takoradi");
    }//GEN-LAST:event_TakoradiLabelMouseExited

    private void KoforiduaLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KoforiduaLabelMouseExited
   KoforiduaLabel.setText("Koforidua");
    }//GEN-LAST:event_KoforiduaLabelMouseExited

    private void HoLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HoLabelMouseExited
   HoLabel.setText("Ho");
    }//GEN-LAST:event_HoLabelMouseExited

    private void WaLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_WaLabelMouseExited
   WaLabel.setText("Wa");
    }//GEN-LAST:event_WaLabelMouseExited

    private void BolgaLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BolgaLabelMouseExited
   BolgaLabel.setText("Bolgatanga");
    }//GEN-LAST:event_BolgaLabelMouseExited

    private void SunyaniLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SunyaniLabelMouseExited
   SunyaniLabel.setText("Sunyani");
    }//GEN-LAST:event_SunyaniLabelMouseExited

    private void KumasiLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KumasiLabelMouseExited
   KumasiLabel.setText("Kumasi");
    }//GEN-LAST:event_KumasiLabelMouseExited

    private void CapeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CapeLabelMouseExited
        CapeLabel.setText("CapeCoast");
    }//GEN-LAST:event_CapeLabelMouseExited

    private void startPanelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_startPanelKeyTyped
        // TODO add your handling code here:
         
    }//GEN-LAST:event_startPanelKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 // TODO add your handling code here:
    Toolkit tkp = TicketPanel.getToolkit();
    PrintJob pjp = tkp.getPrintJob(this,null, null);
    Graphics g = pjp.getGraphics();
    TicketPanel.print(g);
    g.dispose();
    pjp.end();
		
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        UpdateWindow upwin = new UpdateWindow(); 
        upwin.setSize(621,512); 
        upwin.setLocation(400,300);
        upwin.setVisible(true); 
        
        
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btmvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmvActionPerformed
        JFrame mv = new Movements(); 
        mv.pack(); 
        mv.setVisible(true);
        mv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_btmvActionPerformed

    private void aboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutActionPerformed
      JFrame abt = new About(); 
      abt.pack(); 
      abt.setLocation(400,150);
      abt.setVisible(true); 
      abt.setResizable(false); 
      abt.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      abt.setAlwaysOnTop(true);
    }//GEN-LAST:event_aboutActionPerformed

    private void addDriverMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDriverMenuActionPerformed
        JFrame addDriver = new Add_Driver(); 
        addDriver.pack(); 
        addDriver.setVisible(true); 
        addDriver.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
    }//GEN-LAST:event_addDriverMenuActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed

            
            JFrame DL =new DriverDetails();
            DL.pack(); 
            DL.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            DL.setLocation(50,40);
            DL.setVisible(true);
            
  
        
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void newUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newUserActionPerformed
        JFrame New = new NewUser(); 
        New.pack(); 
        New.setVisible(true); 
        
    }//GEN-LAST:event_newUserActionPerformed

    private void TicketOperationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TicketOperationActionPerformed
        JFrame  ticketFrame= new Sell_Tick(); 
//        ticketFrame.pack(); 
//        ticketFrame.setLocation(400,300);
        ticketFrame.setBounds((screen.width - 490) / 2, (screen.height - 300) / 2,328,379); 
        ticketFrame.setVisible(true);
          ticketFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_TicketOperationActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        JFrame DM = new DailyMovementsRecords(); 
        DM.pack(); 
        DM.setVisible(true);
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        Color color = (Color.orange) ; 
             color =JColorChooser.showDialog(null,"Choose a theme color",color);
             if (color==null)
                 color=(Color.orange);
            themeBut1.setBackground(color);
             themeBut.setBackground(color);
             
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void hideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideActionPerformed
    HomePanel.hide();
    }//GEN-LAST:event_hideActionPerformed

    private void showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showActionPerformed
    HomePanel.show();
    }//GEN-LAST:event_showActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
       MainClass.UserInterface(); 
    
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        MainClass.UserWindowsInterface(); 
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        TicketSold_Details tsd = new TicketSold_Details(); 
        tsd.pack(); 
        tsd.setVisible(true);
        tsd.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void MRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MRActionPerformed

                          String ObjButtons[] = {"Yes", "No"};
                    int PromptResult = JOptionPane.showOptionDialog(null, "WARNING! ALL DATA WOULD BE LOST",
                            "Success", JOptionPane.INFORMATION_MESSAGE, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
                    if (PromptResult == 0) {
                        reset=887;
            try {
                while (rst.next()){
                String sql ="DELETE FROM driver_details";
                stmt.executeUpdate(sql);
                String sql2 ="DELETE FROM businfo";
                stmt.executeUpdate(sql2);
                String sql3 ="DELETE FROM income";
                stmt.executeUpdate(sql3);
                String sql4 ="DELETE FROM login where UserName !='Awetrasoft'";
                stmt.executeUpdate(sql4);
                String sql5 ="DELETE FROM routes";
                stmt.executeUpdate(sql5);
                String sql6 ="DELETE FROM revenue";
                stmt.executeUpdate(sql6);
                }
            } catch (SQLException ex) {
                Logger.getLogger(StartPage.class.getName()).log(Level.SEVERE, null, ex);
            }
                        
                        
                    } else {
                        
                    }

    }//GEN-LAST:event_MRActionPerformed

    /**
     * @param args the command line arguments
     */
    


       public void reloaded() {
               try {
//            stmt = ODBC_class.gcetDBConnection().createStatement();
             stmt = CreateDB.getConnection().createStatement();
        } catch (Exception excp) {
            JOptionPane.showMessageDialog(null, "Error on database connection", "Statement error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed

        try {
         String sql = ("SELECT * FROM BusInfo ORDER BY BusNo");
         int Numrow=0;
        
     
             
            ResultSet result = stmt.executeQuery(sql);
            while (result.next()) {
               
                if (run==1){
                     int key =0;
         DefaultTableModel dtm = (DefaultTableModel) table.getModel();
         key = table.getRowCount()+1;
         dtm.setRowCount(key);  
                  
                }else if (UpdateWindow.deleted==887){
                                int key =0;
         DefaultTableModel dtm = (DefaultTableModel) table.getModel();
         key = table.getRowCount()-1;
         dtm.setRowCount(key); 
         
         UpdateWindow.deleted=0; 
                }
                
         
                
                
                table.setValueAt(result.getString(1).trim(), Numrow, 0);
                table.setValueAt(result.getString(2).trim(), Numrow, 1);
                table.setValueAt(result.getString(3).trim(), Numrow, 2);
                table.setValueAt(result.getString(4).trim(), Numrow, 3);
                table.setValueAt(result.getString(5).trim(), Numrow, 4);
                table.setValueAt(result.getString(6).trim(), Numrow, 5);
                table.setValueAt(result.getString(7).trim(), Numrow, 6);
                table.setValueAt(result.getString(8).trim(), Numrow, 7);
       Numrow++;

            }//while closed
           run =0;
        } catch (SQLException sqlex) {
            JOptionPane.showMessageDialog(null, "Error on retrieving values", "Error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed
    }//reloaded() closed
       
       private void ConfirmExit() {
        String ObjButtons[] = {"Yes", "No"};
        int PromptResult = JOptionPane.showOptionDialog(null, "Are you sure to exit?",
                "Confirm exit", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
        if (PromptResult == 0) {
            System.exit(0);
              Logout logout = new Logout(); 
            logout.pack();
              logout.setResizable(false);
              logout.setLocation(400,300);
            logout.setVisible(true);
            
        }//if closed
    }//ConfirmExit() closed
       
     
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AccraLabel;
    private javax.swing.JLabel BolgaLabel;
    private javax.swing.JLabel CapeLabel;
    private javax.swing.JButton GenBut;
    private javax.swing.JLabel HoLabel;
    private javax.swing.JPanel HomePanel;
    private javax.swing.JTabbedPane HomeWindowTabs;
    private javax.swing.JLabel KoforiduaLabel;
    private javax.swing.JLabel KumasiLabel;
    private javax.swing.JMenuItem MR;
    private javax.swing.JLabel SunyaniLabel;
    private javax.swing.JPanel TablePanel;
    private javax.swing.JLabel TakoradiLabel;
    private javax.swing.JLabel TamaleLabel;
    private javax.swing.JPanel TickPanel;
    private javax.swing.JMenuItem TicketOperation;
    private javax.swing.JPanel TicketPanel;
    private javax.swing.JLabel UserPic;
    private javax.swing.JLabel WaLabel;
    private javax.swing.JMenuItem about;
    private javax.swing.JMenuItem addDriverMenu;
    private javax.swing.JMenuItem btmv;
    private javax.swing.JButton btnAddNew;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel clockLabel;
    private javax.swing.JMenu file;
    private javax.swing.JRadioButtonMenuItem hide;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JPopupMenu jPopupMenu3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem menuKbs;
    private javax.swing.JLabel name;
    private javax.swing.JMenuItem newUser;
    private javax.swing.JLabel position;
    public static javax.swing.JTextField serNo;
    private javax.swing.JRadioButtonMenuItem show;
    private javax.swing.JPanel startPanel;
    public static javax.swing.JTable table;
    private javax.swing.JPanel themeBut;
    private javax.swing.JPanel themeBut1;
    private javax.swing.JTextField tickDate;
    private javax.swing.JTextField tickFare;
    private javax.swing.JTextField tickNoPlate;
    private javax.swing.JTextField tickTo;
    private javax.swing.JTextField txtTickFrom;
    private javax.swing.JMenu view;
    // End of variables declaration//GEN-END:variables
    private Random r; 
    int reset;
    private int count =0;
    private int run = 1; 
}
